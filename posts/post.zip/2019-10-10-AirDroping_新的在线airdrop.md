---
layout: post
cid: 26
title: AirDroping|新的在线airdrop
slug: 26
date: 2019/10/10 12:21:00
updated: 2019/10/15 18:59:59
status: publish
author: given
categories: 
  - 网络
tags: 
---


AirDropping是一个隔空投送的网页应用程序，您可以使用他来传输一些大文件。

制作这个程序是因为在国内的大多的临时传输工具都需要付费，而且会限制传输速度和文件大小，因此制作这一款不限制空间和速度的临时传输工具。
![index](https://2890.ltd/usr/uploads/2019/10/417662218.webp)


此工具的使用方法很简单，只需要打开网站https://file.2890.ltd即可，打开后点击发送会跳转到另外一个界面。
![upload_php](https://2890.ltd/usr/uploads/2019/10/2381105579.webp)


进入此界面后点击选择文件将弹出选择框，再次就可以选择您要上传的文件了。

请注意，由于php运行时单个文件仅限200MB，且只会保存一天，第二天自动失效

文件选择完毕后点击上传按钮即可，上传完毕后会跳转到另一个界面。
![upload_php](https://2890.ltd/usr/uploads/2019/10/2519189626.webp)
请您记住此段取件码，这是您获取文件的凭借。

下载您传输的文件需要再次回到主页https://file.2890.ltd,

点击接收您将跳转到另一个界面
![233_php](https://2890.ltd/usr/uploads/2019/10/975053562.webp)


您只需要将取件码输入没有内容的方框中再点击提交即可下载您的文件。

谢谢您的支持！！！

