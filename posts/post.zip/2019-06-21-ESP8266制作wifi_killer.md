---
layout: post
cid: 12
title: ESP8266制作wifi killer
slug: 12
date: 2019/06/21 00:07:00
updated: 2019/06/21 00:56:03
status: publish
author: given
categories: 
  - 杂
tags: 
sub: 
---


## 引子 ##
想必大家都有被蹭网的经历吧，大家想必都很讨厌这种情况吧，今天我就来教大家制作一个wifi设备干扰器
## 需要材料 ##
esp8266板子 购买[传送门][1]
安卓micro usb线材或usb转ttl线
## 完成照片 ##
![IMG_20190620_192507.jpg][2]
## 步骤 ##
首先，下载固件与烧录工具（评论区会有）
然后，刷入固件
![IMG_20190620_192518.jpg][3]
刷好后进入一个叫WI-PWN的wifi，用chrome打开192.168.4.1
之后该怎么玩，就怎么玩


  [1]: https://m.tb.cn/h.eUIO7JU?sm=a2454a
  [2]: https://okyes.site/usr/uploads/2019/06/2497624522.jpg
  [3]: https://okyes.site/usr/uploads/2019/06/1106989594.jpg